#include <Python.h>
#include "MinaCalc/MinaCalc.h"
#include "MinaCalc/MinaCalcHelpers.h"

static PyObject *method_version(PyObject *self, PyObject *args) 
{
    printf("%d", GetCalcVersion());
    return PyLong_FromLong(0);
}

static PyObject *method_calc_skill_set(PyObject *self, PyObject *args) 
{
    float rate = 0.0, score_goal = default_score_goal;
    PyObject *noteBuff = nullptr;
    PyArg_ParseTuple(args, "fO|f", &rate, &noteBuff, &score_goal);
    Py_ssize_t size = PyList_Size(noteBuff);
    auto noteInfo = new NoteInfo[size];
    long currentTime = -1L;
    unsigned int currentNotes = 0;
    size_t count = 0;
    for (Py_ssize_t i = 0; i < size; i++) {
        auto timeColumnTuple = PyList_GetItem(noteBuff, i);
        auto timeMS = PyLong_AsLong(PyTuple_GetItem(timeColumnTuple, 0));
        auto column = PyLong_AsLong(PyTuple_GetItem(timeColumnTuple, 1));
        if (currentTime != timeMS) {
            if (currentNotes != 0) {
                noteInfo[count].notes = currentNotes;
                noteInfo[count++].rowTime = currentTime / (float) 1000;
                // printf("[%zd] note = %d, time = %lf\n", count - 1, currentNotes, (float) currentTime / 1000.0);
                currentNotes = 0;
            }
            currentTime = timeMS;
        }
        currentNotes |= 1 << column;
    }
    if (currentNotes != 0) {
        noteInfo[count].notes = currentNotes;
        noteInfo[count++].rowTime = currentTime / (float) 1000;
        // printf("[%zd] note = %d, time = %lf\n", count - 1, currentNotes, (float) currentTime / 1000.0);
    }

    std::vector<NoteInfo> noteInfoVector(noteInfo, noteInfo + count);
    Calc* calc = new Calc;
    auto ssr = MinaSDCalc(noteInfoVector, rate, default_score_goal, calc);
    
    delete calc;
    delete[] noteInfo;


    return PyTuple_Pack(ssr.size(), 
        PyFloat_FromDouble(ssr[0]), 
        PyFloat_FromDouble(ssr[1]), 
        PyFloat_FromDouble(ssr[2]), 
        PyFloat_FromDouble(ssr[3]), 
        PyFloat_FromDouble(ssr[4]), 
        PyFloat_FromDouble(ssr[5]), 
        PyFloat_FromDouble(ssr[6]), 
        PyFloat_FromDouble(ssr[7])
    );
}

static PyMethodDef MinaCalcMethods[] = {
    {"version", method_version, METH_VARARGS, "Print MinaCalc version"},
    {"calc_skill_set", method_calc_skill_set, METH_VARARGS, "Calculate skill set"},
    {NULL, NULL, 0, NULL}
};


static struct PyModuleDef MinaCalcModule = {
    PyModuleDef_HEAD_INIT,
    "minacalc",
    "Python interface for MinaCalc",
    -1,
    MinaCalcMethods
};

PyMODINIT_FUNC PyInit_minacalc(void) 
{
    return PyModule_Create(&MinaCalcModule);
}