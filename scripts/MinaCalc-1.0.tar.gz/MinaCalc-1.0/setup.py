from distutils.core import setup, Extension

setup(
    name = 'MinaCalc',
    version = '1.0',
    description = 'Python interface for MinaCalc',
    ext_modules = [
        Extension(
            'minacalc',
            extra_compile_args=['/std:c++17'],
            undef_macros=['NDEBUG'],
            sources=['MinaCalcModule.cpp', 'MinaCalc/MinaCalc.cpp']
        )
    ])